<!-- Main component for a primary marketing message or call to action -->
<div class="jumbotron">
	<h1><?php echo $heading; ?></h1>
	<p><?php echo $paragraph; ?></p>
</div>
