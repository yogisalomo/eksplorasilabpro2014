<!-- Main component for a primary marketing message or call to action -->
<div class="jumbotron">
	<h1>Welcome</h1>
	<p>Andarias Silvanus - 13512022</p>
	<p>Willy - 13512070</p>
</div>