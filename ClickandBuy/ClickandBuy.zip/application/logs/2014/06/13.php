<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-06-13 09:27:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:27:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:27:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:27:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:27:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:27:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:27:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:27:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:27:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:27:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:27:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:27:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:29:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:29:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:29:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:29:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: data/opel_asd.jpg ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 09:48:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL profile was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 09:48:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL profile was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 09:49:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL profile/opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2014-06-13 09:49:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL profile/opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 09:49:22 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model::getdata() ~ APPPATH/classes/controller/profile.php [ 7 ]
2014-06-13 09:49:22 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model::getdata() ~ APPPATH/classes/controller/profile.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 09:49:46 --- ERROR: ErrorException [ 8 ]: Undefined variable: _username ~ APPPATH/classes/controller/profile.php [ 7 ]
2014-06-13 09:49:46 --- STRACE: ErrorException [ 8 ]: Undefined variable: _username ~ APPPATH/classes/controller/profile.php [ 7 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/opt/lampp/htdo...', 7, Array)
#1 [internal function]: Controller_Profile->action_index()
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#6 {main}
2014-06-13 09:49:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/ico/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 09:49:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: assets/ico/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:01:15 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/views/browse.php [ 9 ]
2014-06-13 10:01:15 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/views/browse.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 10:25:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/index/opel2 ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 10:25:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/index/opel2 ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:26:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 10:26:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:26:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel/opel ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 10:26:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel/opel ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:27:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel/opel ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 10:27:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel/opel ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:27:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 10:27:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:28:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL profile/opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2014-06-13 10:28:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL profile/opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 10:28:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL profile/opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2014-06-13 10:28:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL profile/opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 10:34:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: profile ~ APPPATH/views/profile.php [ 2 ]
2014-06-13 10:34:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: profile ~ APPPATH/views/profile.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/profile.php(2): Kohana_Core::error_handler(8, 'Undefined varia...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:37:38 --- ERROR: ErrorException [ 1 ]: Class 'getAllByUsernameTitleCategory' not found ~ APPPATH/classes/controller/profile.php [ 8 ]
2014-06-13 10:37:38 --- STRACE: ErrorException [ 1 ]: Class 'getAllByUsernameTitleCategory' not found ~ APPPATH/classes/controller/profile.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 10:37:58 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Model_Item::getAllByUsernameTitleCategory(), called in /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php on line 8 and defined ~ APPPATH/classes/model/item.php [ 36 ]
2014-06-13 10:37:58 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Model_Item::getAllByUsernameTitleCategory(), called in /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php on line 8 and defined ~ APPPATH/classes/model/item.php [ 36 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(36): Kohana_Core::error_handler(2, 'Missing argumen...', '/opt/lampp/htdo...', 36, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(8): Model_Item::getAllByUsernameTitleCategory()
#2 [internal function]: Controller_Profile->action_index()
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#7 {main}
2014-06-13 10:39:32 --- ERROR: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH/classes/controller/profile.php [ 9 ]
2014-06-13 10:39:32 --- STRACE: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH/classes/controller/profile.php [ 9 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', '/opt/lampp/htdo...', 9, Array)
#1 [internal function]: Controller_Profile->action_index()
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#6 {main}
2014-06-13 10:40:05 --- ERROR: Database_Exception [ 1054 ]: [1054] Unknown column 'title' in 'where clause' ( SELECT * FROM `item` WHERE `username` = 'opel' AND `title` = 'this' AND `category` = 'that' ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
2014-06-13 10:40:05 --- STRACE: Database_Exception [ 1054 ]: [1054] Unknown column 'title' in 'where clause' ( SELECT * FROM `item` WHERE `username` = 'opel' AND `title` = 'this' AND `category` = 'that' ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQLi->query(1, 'SELECT * FROM `...', false, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(42): Kohana_Database_Query->execute()
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Model_Item::getAllByUsernameTitleCategory('opel', 'this', 'that')
#3 [internal function]: Controller_Profile->action_index()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 10:40:45 --- ERROR: Database_Exception [ 1054 ]: [1054] Unknown column 'title' in 'where clause' ( SELECT * FROM `item` WHERE `username` = 'opel' AND `title` = 'that' AND `category` = 'this' ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
2014-06-13 10:40:45 --- STRACE: Database_Exception [ 1054 ]: [1054] Unknown column 'title' in 'where clause' ( SELECT * FROM `item` WHERE `username` = 'opel' AND `title` = 'that' AND `category` = 'this' ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQLi->query(1, 'SELECT * FROM `...', false, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(42): Kohana_Database_Query->execute()
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Model_Item::getAllByUsernameTitleCategory('opel', 'this', 'that')
#3 [internal function]: Controller_Profile->action_index()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 10:41:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: _title ~ APPPATH/classes/model/item.php [ 40 ]
2014-06-13 10:41:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: _title ~ APPPATH/classes/model/item.php [ 40 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', '/opt/lampp/htdo...', 40, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Model_Item::getAllByUsernameTitleCategory('opel', 'this', 'that')
#2 [internal function]: Controller_Profile->action_index()
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#7 {main}
2014-06-13 10:41:23 --- ERROR: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:41:23 --- STRACE: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:41:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/assets/ico/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 10:41:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/assets/ico/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 10:41:28 --- ERROR: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:41:28 --- STRACE: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:49:06 --- ERROR: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:49:06 --- STRACE: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:50:43 --- ERROR: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:50:43 --- STRACE: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:50:45 --- ERROR: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:50:45 --- STRACE: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:50:57 --- ERROR: View_Exception [ 0 ]: The requested view gila could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2014-06-13 10:50:57 --- STRACE: View_Exception [ 0 ]: The requested view gila could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(137): Kohana_View->set_filename('gila')
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(30): Kohana_View->__construct('gila', NULL)
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Kohana_View::factory('gila')
#3 [internal function]: Controller_Profile->action_index()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 10:51:01 --- ERROR: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:51:01 --- STRACE: ErrorException [ 8 ]: Undefined index: username ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:51:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type View as array ~ APPPATH/classes/controller/profile.php [ 9 ]
2014-06-13 10:51:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type View as array ~ APPPATH/classes/controller/profile.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 10:51:35 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/profile.php [ 9 ]
2014-06-13 10:51:35 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/profile.php [ 9 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Kohana_Core::error_handler(8, 'Undefined offse...', '/opt/lampp/htdo...', 9, Array)
#1 [internal function]: Controller_Profile->action_index()
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#6 {main}
2014-06-13 10:56:17 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ',' or ';' ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:56:17 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ':', expecting ',' or ';' ~ APPPATH/views/item.php [ 2 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 10:56:32 --- ERROR: ErrorException [ 8 ]: Undefined variable: items ~ APPPATH/views/item.php [ 2 ]
2014-06-13 10:56:32 --- STRACE: ErrorException [ 8 ]: Undefined variable: items ~ APPPATH/views/item.php [ 2 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/views/item.php(2): Kohana_Core::error_handler(8, 'Undefined varia...', '/opt/lampp/htdo...', 2, Array)
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /opt/lampp/htdocs/ClickandBuy/application/views/template.php(19): Kohana_View->__toString()
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(61): include('/opt/lampp/htdo...')
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(343): Kohana_View::capture('/opt/lampp/htdo...', Array)
#7 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Profile))
#10 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#12 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#13 {main}
2014-06-13 10:56:44 --- ERROR: View_Exception [ 0 ]: The requested view items could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2014-06-13 10:56:44 --- STRACE: View_Exception [ 0 ]: The requested view items could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(137): Kohana_View->set_filename('items')
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/view.php(30): Kohana_View->__construct('items', NULL)
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/profile.php(9): Kohana_View::factory('items')
#3 [internal function]: Controller_Profile->action_index()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Profile))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 21:38:06 --- ERROR: ErrorException [ 1 ]: Call to undefined function UNIX_TIMESTAMP() ~ APPPATH/views/item.php [ 9 ]
2014-06-13 21:38:06 --- STRACE: ErrorException [ 1 ]: Call to undefined function UNIX_TIMESTAMP() ~ APPPATH/views/item.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 22:42:01 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model::addComment() ~ APPPATH/classes/controller/upload.php [ 46 ]
2014-06-13 22:42:01 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model::addComment() ~ APPPATH/classes/controller/upload.php [ 46 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 22:42:11 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/upload.php [ 46 ]
2014-06-13 22:42:11 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/upload.php [ 46 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php(46): Kohana_Core::error_handler(8, 'Undefined index...', '/opt/lampp/htdo...', 46, Array)
#1 [internal function]: Controller_Upload->action_upload_comment()
#2 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Upload))
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#6 {main}
2014-06-13 22:43:06 --- ERROR: Database_Exception [ 1054 ]: [1054] Unknown column 'commentator' in 'field list' ( INSERT INTO `item` (`username`, `timestamp`, `commentator`, `comment`) VALUES ('opel', 1402717386, NULL, 'hello') ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
2014-06-13 22:43:06 --- STRACE: Database_Exception [ 1054 ]: [1054] Unknown column 'commentator' in 'field list' ( INSERT INTO `item` (`username`, `timestamp`, `commentator`, `comment`) VALUES ('opel', 1402717386, NULL, 'hello') ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQLi->query(2, 'INSERT INTO `it...', false, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(48): Kohana_Database_Query->execute()
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php(46): Model_Item::addComment('opel', 'hello')
#3 [internal function]: Controller_Upload->action_upload_comment()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Upload))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 22:43:37 --- ERROR: Database_Exception [ 1452 ]: [1452] Cannot add or update a child row: a foreign key constraint fails (`ClickandBuy`.`comment`, CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`username`, `timestamp`) REFERENCES `item` (`username`, `timestamp`) ON DELETE CASCADE) ( INSERT INTO `comment` (`username`, `timestamp`, `commentator`, `comment`) VALUES ('opel', 1402717417, NULL, 'hello') ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
2014-06-13 22:43:37 --- STRACE: Database_Exception [ 1452 ]: [1452] Cannot add or update a child row: a foreign key constraint fails (`ClickandBuy`.`comment`, CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`username`, `timestamp`) REFERENCES `item` (`username`, `timestamp`) ON DELETE CASCADE) ( INSERT INTO `comment` (`username`, `timestamp`, `commentator`, `comment`) VALUES ('opel', 1402717417, NULL, 'hello') ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(48): Kohana_Database_Query->execute()
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php(46): Model_Item::addComment('opel', 'hello')
#3 [internal function]: Controller_Upload->action_upload_comment()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Upload))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 22:50:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 22:50:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 22:50:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 22:50:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL opel was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 22:50:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL opel/this/that was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 22:50:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL opel/this/that was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 22:50:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL opel/that/this was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 22:50:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL opel/that/this was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 22:54:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel/that/this ~ SYSPATH/classes/kohana/request.php [ 1152 ]
2014-06-13 22:54:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/opel/that/this ~ SYSPATH/classes/kohana/request.php [ 1152 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#1 {main}
2014-06-13 22:54:59 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected 'else' (T_ELSE) ~ APPPATH/classes/controller/profile.php [ 11 ]
2014-06-13 22:54:59 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected 'else' (T_ELSE) ~ APPPATH/classes/controller/profile.php [ 11 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 22:55:32 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Item::getInfo() ~ APPPATH/classes/controller/profile.php [ 9 ]
2014-06-13 22:55:32 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Item::getInfo() ~ APPPATH/classes/controller/profile.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 22:55:59 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_User::getComment() ~ APPPATH/classes/controller/profile.php [ 10 ]
2014-06-13 22:55:59 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_User::getComment() ~ APPPATH/classes/controller/profile.php [ 10 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-06-13 22:58:42 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Model_Item::addComment(), called in /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php on line 46 and defined ~ APPPATH/classes/model/item.php [ 44 ]
2014-06-13 22:58:42 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Model_Item::addComment(), called in /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php on line 46 and defined ~ APPPATH/classes/model/item.php [ 44 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(44): Kohana_Core::error_handler(2, 'Missing argumen...', '/opt/lampp/htdo...', 44, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php(46): Model_Item::addComment('opel', 'hello2')
#2 [internal function]: Controller_Upload->action_upload_comment()
#3 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Upload))
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#7 {main}
2014-06-13 23:07:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL ope/1402714956 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 23:07:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL ope/1402714956 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 23:07:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL ope/1402714956 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 23:07:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL ope/1402714956 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}
2014-06-13 23:07:38 --- ERROR: Database_Exception [ 1062 ]: [1062] Duplicate entry 'opel-1402714956' for key 'PRIMARY' ( INSERT INTO `comment` (`username`, `timestamp`, `commentator`, `comment`, `comment_timestamp`) VALUES ('opel', 1402714956, NULL, 'hello', 1402718858) ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
2014-06-13 23:07:38 --- STRACE: Database_Exception [ 1062 ]: [1062] Duplicate entry 'opel-1402714956' for key 'PRIMARY' ( INSERT INTO `comment` (`username`, `timestamp`, `commentator`, `comment`, `comment_timestamp`) VALUES ('opel', 1402714956, NULL, 'hello', 1402718858) ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(47): Kohana_Database_Query->execute()
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php(46): Model_Item::addComment('opel', 1402714956, 'hello')
#3 [internal function]: Controller_Upload->action_upload_comment()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Upload))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 23:11:31 --- ERROR: Database_Exception [ 1048 ]: [1048] Column 'commentator' cannot be null ( INSERT INTO `comment` (`username`, `timestamp`, `commentator`, `comment`, `comment_timestamp`) VALUES ('opel', 1402714956, NULL, 'hello', 1402719091) ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
2014-06-13 23:11:31 --- STRACE: Database_Exception [ 1048 ]: [1048] Column 'commentator' cannot be null ( INSERT INTO `comment` (`username`, `timestamp`, `commentator`, `comment`, `comment_timestamp`) VALUES ('opel', 1402714956, NULL, 'hello', 1402719091) ) ~ MODPATH/database/classes/kohana/database/mysqli.php [ 182 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 /opt/lampp/htdocs/ClickandBuy/application/classes/model/item.php(47): Kohana_Database_Query->execute()
#2 /opt/lampp/htdocs/ClickandBuy/application/classes/controller/upload.php(46): Model_Item::addComment('opel', 1402714956, 'hello')
#3 [internal function]: Controller_Upload->action_upload_comment()
#4 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Upload))
#5 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#7 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#8 {main}
2014-06-13 23:11:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL opel/1402714956 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2014-06-13 23:11:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL opel/1402714956 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /opt/lampp/htdocs/ClickandBuy/system/classes/kohana/request.php(1164): Kohana_Request_Client->execute(Object(Request))
#2 /opt/lampp/htdocs/ClickandBuy/index.php(109): Kohana_Request->execute()
#3 {main}