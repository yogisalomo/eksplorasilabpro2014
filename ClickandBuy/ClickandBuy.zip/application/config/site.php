<?php defined('SYSPATH') or die('No direct script access.');
return array(
	'name' => 'Click and Buy',
	'tag_line' => "Let's talk about me!"
);