$("#message-form").hide();
$("#message-show").click(function() {
	$(this).hide();
	$("#message-form").show();
});
console.log("Successful");